import React ,{useState}from 'react'
import {useHistory} from "react-router-dom";


function Login(){
    const[email,setEmail]=useState(null)
    const[passward,setPassward]=useState(null)
    const history=useHistory()
    // let data={
    //     request : 'candidate_login',
    //     email:email,
    //     papassword : passward
    // }
    
    const login=()=>{
        // if(email=="shalinim@gmail.com" && passward==123){
        //     fetch('http://karka.academy/api/action.php',{
        //         method:'post',
        //         body:JSON.stringify(data)
        //     }).then((data)=>data.JSON())
        //     .then((respose)=>console.log(respose))
        //     .catch(alert(1))
          if(email=="shalinim@gmail.com" && passward==123){

        
             history.push({
              pathname: '/home',
              search: '?query=abc',
              state: {detail: email}
             })
         }
    }
    window.history.forward()
       
    
    return(
        <div>
            <span>Email</span>
            <input type="text" value={email} onChange={(e)=>setEmail(e.target.value)}/><br/>
            <span>Passward</span>
            <input type="text" value={passward} onChange={(e)=>setPassward(e.target.value)}/><br/>
            <button onClick={login}>log in</button>
        </div>
    )
}
export default Login;