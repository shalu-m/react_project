import React from "react";
import ManinRoute from "./routs";

export default function App() {
  return (
    <div>
      <ManinRoute/>
    </div>
  )
}



