import React from "react";
import ManinRoute from './routs'

function App(){
  return (
    <div>
      
      <ManinRoute />
    </div>
  )
}

export default App



