import React,{useEffect, useState} from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import '../App.css'


export default function CourseList(){
    const[courseList,setCourseList]=useState([])
    useEffect(
        ()=>{getCourselist()},
        []
    )
    const getCourselist=async()=>{
        const {data}=await axios.get("http://karka.academy/api/action.php?request=getCourses")
        setCourseList(data.data)
        console.log(data)
    }
    
    return(
        <div>
            <div>

                <h3 className="courselist">Course List</h3>
                {courseList.map((item,index)=>{
                    return(
                        <div key={item.id}>
                            <table className="table table-warning">
                                <tbody>
                                    <tr>
                                        <th scope="row" className="col-3">{index+1}</th>
                                        <td className="col-9"><Link to={`/course/${item.id}`} className="_list">{item.name}</Link></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    )
                })}
                
                <ul>
                    {courseList.map(item=><li key={item.id} className="list"></li>)}
                </ul>
            </div>
        </div>
    )
}
