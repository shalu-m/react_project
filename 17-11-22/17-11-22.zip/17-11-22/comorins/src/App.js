import React, {Component} from 'react'
import PostStatus from './postStatus'
import StatusList from './statusList'
import './App.css';




class App extends Component{
  constructor(props){
    super(props);
    this.state={
      updateText:"",
      message:[
        "hollo world"
      ]

    }

  }
  
  submitStatus=()=>{
   
     if(this.state.updateText.trim()){
      let newtext=[...this.state.message,this.state.updateText]
      this.setState({
        updateText:"",
        message:newtext
      })
     }
    
  }
  
  statusChange=(event)=>{
    this.setState({
      updateText:event.target.value,
      
    })

  }
  delstatus=(index)=>{
    let listcopy=[...this.state.message]
    listcopy.splice(index,1)
    this.setState({
      message:listcopy
    })
  }
 
  render(){
    return (
      <div className='textarea'>
        <h2 className="title">Status Update</h2>
        <PostStatus submitStatus={this.submitStatus} statusValue={this.state.updateText} statusChange={this.statusChange}/>
        <StatusList message={this.state.message} delstatus={this.delstatus}/>
      </div>
    );
  }
}

export default App;


