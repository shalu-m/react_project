import './App.css';

function Sidebar(){
    return(
       
    <div>
        <ul>
            <li class="pb-3">link1</li>
            <li class="pb-3">link2</li>
            <li class="pb-3">link3</li>
            <li class="pb-3">link4</li>
        </ul>
    </div>

        
    )
}
export default Sidebar;

