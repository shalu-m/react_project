import React from 'react'
import './App.css';

const StatusList=({message,delstatus})=>{
    return(
        <div>
            {!message.length?(
                <p className='no_status'> No status here...</p>
            ):(message.map((status,index)=>(
                <div key={index} className="content">
                    <p className='text-color'>{status}</p>
                    <button onClick={()=>delstatus(index)} className='del-btn'>remove</button>
                </div>
            )))}

            
                
            
        </div>
    )
}

export default StatusList