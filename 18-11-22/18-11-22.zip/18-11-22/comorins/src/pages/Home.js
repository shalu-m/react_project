import React,{useContext, useEffect} from "react";
import Header from "../Components/header";
import { useNavigate } from "react-router-dom";
import CourseList from "../Components/courseList";
import userContext from "./main";
import Members from "../Components/member";


function Home(){
    let value=useContext(userContext)
    let {login,setLogin}=value
    let navigate=useNavigate()
    let LogIn=localStorage.getItem('log_in')
    useEffect(
        ()=>{
            if(login || LogIn==='true'){ navigate('/home')}else{navigate('/')} },
        [login,LogIn]
    )

    return(
        <div>
            <Header setLogin={setLogin}/>
            <div className="container-fluid section">
                <div className="row">
                    <div className="col-3">
                        <Members/>
                    </div>
                    <div className="col-9">
                        <CourseList/>
                    </div>
                </div>
            </div>
        </div>
    )
}
 
export default Home;