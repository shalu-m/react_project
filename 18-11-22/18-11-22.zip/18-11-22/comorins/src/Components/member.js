import React,{useEffect, useState} from "react";
import axios from "axios";

import 'bootstrap/dist/css/bootstrap.min.css';
import '../App.css'



export default function Members(){

    useEffect(()=>{
        getMembers()
    },[])
    const [Members,setMembers]=useState()
    const getMembers= async()=>{
        const {data}=await axios.get(`http://karka.academy/api/action.php?request=getAllMembers`)
        console.log(`members...`,data.data)
        setMembers(data.data)
    }
    return(
        <div>
            <h3>Members</h3>
            {Members && Members.map((value,index)=>{
                return(
                    <div key={index}>
                        <table className="table table-warning">
                            <tbody>
                                <tr>
                                    <th scope="row" className="3">{index+1}</th>
                                    <td className="col-9">{value.name}</td>
                                </tr>
                            </tbody>
                        </table>
                       
                    </div>
                )
                
            })}
            
        </div>
    )
}