//import React from 'react';
import Hello from './text1.js'
import Stopwatch from './stopwatch'
import React ,{useState}from 'react'


 function Welcome(){
    const[name,setName]=useState(0)
     return(
         <div>
             <h1>{name}</h1>

             
             <Hello name={setName}/>
             
            <button onClick={()=>setName(name+1)}>increase</button>
            <button onClick={()=>setName(name-1)}>decrease</button>
            <Stopwatch/>
            
         </div>
     )
 }




// class Welcome extends React.Component {
 
//   constructor(props){
//       super(props);
//       this.state = {
//           name : "Ramesh",
//           place : "NGL",
//           education: "BE",
//           phone : "123244",
//       }
//   }
//   testt(name){
//       this.setState({
//           ...this.state,
//               name
//       });
//   }

//   render(){
//       return (<>
//           <h1>{this.state.name}</h1>
//           <button onClick={this.testt.bind(this,"Sumesh")}>Change Name</button>
//           <Test name={this.state.name} changeName = {this.testt.bind(this)}/>
//       </>);
//   }

// }



export default Welcome;
