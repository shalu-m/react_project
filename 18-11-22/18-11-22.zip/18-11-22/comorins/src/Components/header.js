import 'bootstrap/dist/css/bootstrap.min.css';

import React from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router";

function Header({setLogin}){
    let navigate=useNavigate()

    const checkLogin=()=>{
        setLogin(false)
        localStorage.setItem(`log_in`,false)
        navigate('/')
        
    } 
    return(
        <div>
            <div className='header'>
                <div className='container-fluid'>
                    <nav className="navbar navbar justify-content-between">
                        <h3 className="navbar-brand"><Link to={'/home'} className='home'>Home</Link></h3>
                        <form className="form-inline">
                            <button className="btn btn-danger my-2 my-sm-0" type="button"><Link to={'/createcourse'} className='courseButton'>Create Course</Link></button>
                            <button className="btn btn-success my-2 my-sm-0 ml-2" type="button" onClick={checkLogin}>Log out</button>
                        </form>
                    </nav>
                </div>
            </div>
           
        </div>
    )
}
export default Header;