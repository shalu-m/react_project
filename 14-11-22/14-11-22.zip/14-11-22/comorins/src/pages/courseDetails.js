function Coursedetails(){
    return(
        <div>
            <h2>Course Details</h2>
        </div>
    )
}
export default Coursedetails 