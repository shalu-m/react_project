function Courselist(){
    return(
        <div>
            <h2>Course List</h2>
        </div>
    )
}
export default Courselist 