import React, { useEffect } from "react";
import  {useState} from 'react'


 
import {
    BrowserRouter as Router,
    Routes,
    Route
} from 'react-router-dom'
import Home from './pages/Home'
import Login from './pages/Login'
import CourseSingle from "./pages/CourseSingle";
import Register from "./pages/Register";
import CreateCourse from "./pages/CreateCourse";
import userContext from "./pages/main";


function ManinRoute(){

    const[login,setLogin]=useState(false)
    return(
        <userContext.Provider value={{login,setLogin}}>
            <Router>
                <Routes>
                    <Route path="/" exact element={<Login />}/>
                    <Route path="/home" element={<Home/>}/>
                    <Route path="/course/:id" element={<CourseSingle/>}></Route>
                    <Route path="/register" element={<Register/>}></Route>
                    <Route path="/createcourse" element={<CreateCourse/>}></Route>
                    
                </Routes>
            </Router>
        </userContext.Provider>
    )
}
export default ManinRoute