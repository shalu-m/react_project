import React ,{useState}from 'react'


function Container(props){
    const[name,setName]=useState(null)
    const[email,setEmail]=useState(null)
    const[Passward,setPasward]=useState(null)

    const a=()=>{
       if(email == "shalinim2000m@gmail.com" && Passward=="123"){
        props.setLogin(true)
        props.setUsername(name)
       }
    }
    return(
        <div class="container-fluid">
            { !props.login?<div><label>Name</label>
            <input type="text" onKeyUp={(e)=>setName(e.target.value)}/><br/>
            <label>Email</label>
            <input type="email" onKeyUp={(e)=>setEmail(e.target.value)}/><br/>
            <label>Passward</label>
            <input type="text" onKeyUp={(e)=>setPasward(e.target.value)}/><br/>
            <button onClick={a}>log in</button></div>:<p>container</p>}
        </div>
    )
}
export default Container;