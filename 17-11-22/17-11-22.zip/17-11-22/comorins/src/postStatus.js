import React from 'react'
import './App.css';

const PostStatus=({submitStatus,statusValue,statusChange})=>{
    return(
        <div className='total-test'>
            <div>
                <form>
                    <textarea className='text-area' placeholder='Text something here...' value={statusValue} onChange={event=>statusChange(event)}/>
                </form>
            </div>
            {statusValue.trim().length?(
                <div>
                    <button className='btn-right' onClick={submitStatus}>Submit</button>
                </div>
            ):null}
            
        </div>
    )
}
export default PostStatus;