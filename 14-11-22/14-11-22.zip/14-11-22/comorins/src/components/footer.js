function Footer(){
    return(
        <>
        <h2>footer</h2>
        </>
    )
}
export default Footer;