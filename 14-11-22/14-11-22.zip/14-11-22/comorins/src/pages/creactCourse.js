function CreateCourse(){
    return(
        <div>
            <h2>Create Course</h2>
        </div>
    )
}
export default CreateCourse 