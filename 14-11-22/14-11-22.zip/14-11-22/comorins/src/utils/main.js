import React ,{useState}from 'react'
import Register from '../pages/register'
 
 function Main(){
    const [user,setUserdetails]=useState([])
    const [email,setEmail]=useState("")
    const [name,setName]=useState("")
    const [Passward,setPassward]=useState("")
    console.log(user)



   const getdetails=()=>{
        if(email && name && Passward){
            let num=user.length+1
            let list={id:num,name:name, Passward:Passward, email:email}
            setUserdetails([...user,list])
            
        }
   }
    return(
        < Register setEmail={setEmail} setName={setName} setPassward={setPassward} email={email} name={name} Passward={Passward} getdetails={getdetails}/>
    )
 }
 export default Main