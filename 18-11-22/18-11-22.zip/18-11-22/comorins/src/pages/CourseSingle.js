import React,{useContext, useEffect, useState} from "react";
import axios from "axios";
import { Link, useNavigate ,useParams} from "react-router-dom";
import CourseList from "../Components/courseList";
import Header from "../Components/header";
import 'bootstrap/dist/css/bootstrap.min.css';
import userContext from "./main";

export default function CourseSingle(){

    let value=useContext(userContext)
    let {login,setLogin}=value

    const params=useParams()
    const[courseDetails,setCourseDetails]=useState({})
    let LogIn=localStorage.getItem('log_in')

    const navigate=useNavigate()
    useEffect(
        ()=>{
            if(!login && LogIn=='false') navigate("/") 
            details(params.id)
        },[params.id,login]
    )

    const details=async()=>{
        const {data}=await axios.get(`http://karka.academy/api/action.php?request=getCourseDetails&id=${params.id}`)
        setCourseDetails(data.data)
    }
    return(
        <div>
            <Header setLogin={setLogin}/>
            <div className="container-fluid">
                <div className="row">
                    
                    <div className="col-2">
                        <CourseList/>
                    </div>
                    <div className="col-10 section">
                        <h3 className="courselist ">Course Details</h3>
                        <div className="body_section">
                            <table className="table">
                                <tbody>
                                    <tr>
                                        <th scope="row">Course name :</th>
                                        <td>{courseDetails.name}</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Price :</th>
                                        <td>{courseDetails.price}</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Time :</th>
                                        <td>{courseDetails.time}</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Video :</th>
                                        <td>{courseDetails.video_id}</td>
                                    </tr>
                                </tbody>
                            </table>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}