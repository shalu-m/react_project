
import React from 'react'

function Register({setEmail,setPassward,setName,getdetails,email,Passward,name}){
    
    
    

return(
        <div>
            <span>Name</span>
            <input type="text"  onChange={(e)=>setName(e.target.value)}/><br/>
            <span>Email</span>
            <input type="text"  onChange={(e)=>setEmail(e.target.value)}/><br/>
            <span>Passward</span>
            <input type="text"  onChange={(e)=>setPassward(e.target.value)}/><br/>
            <button onClick={getdetails}>Register</button>
        </div>
    )
}
export default Register