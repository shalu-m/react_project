function Header(){
    return(
        <div>
            <h2>header</h2>
            <h3>log in</h3>
        </div>

    )
}

export default Header;