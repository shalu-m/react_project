import logo from './logo.svg';
import './App.css';
import Navbar from './navbar';
// import Sidebar from './sidebar';
import Container from './container';
import React ,{useState}from 'react'

function App() {
    const[login,setLogin]=useState(false)
    const[username,setUsername]=useState("")

  
  return (
    <div>
      
      <Navbar username={username} setLogin={setLogin} login={login}/>
      <Container setLogin={setLogin} setUsername={setUsername} login={login}/>
      
      
    </div>
  );
}

export default App;


