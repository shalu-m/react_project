import {useLocation} from "react-router-dom";

function Home(){
    let location=useLocation()
    return(
        <div>

            <h2>Home</h2>
           <p>{location.state.detail}</p>

        </div>
    )
}
export default Home