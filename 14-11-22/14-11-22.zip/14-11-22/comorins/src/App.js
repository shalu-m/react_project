import React from "react";
import Register from './pages/register'
import Login from './pages/login'
import Home from './pages/home';
import CreateCourse from './pages/creactCourse';
import Courselist from './pages/courseList'
import Coursedetails from './pages/courseDetails';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  useRouteMatch,
  useParams
} from "react-router-dom";

export default function App() {
  return (
    <Router>
      <div>
        <ul>
         
          <li>
            <Link to="/register">Register</Link>
          </li>
          <li>
            <Link to="/login">Log in</Link>
          </li>
          <li>
            <Link to='/home'>Home</Link>
          </li>
          <li>
            <Link to="/creatcourse">Create Course</Link>
          </li>
          <li>
            <Link to="/coursedetails">Course Details</Link>
          </li>
          <li>
            <Link to="/courselist">Course list</Link>
          </li>
        </ul>

        <Switch>
          <Route path="/register">
            <Register />
          </Route>
          <Route path="/login">
            <Login />
          </Route>
          <Route path="/home">
            <Home />
          </Route>
          <Route path="/creatcourse">
            <CreateCourse />
          </Route>
          <Route path="/coursedetails">
            <Coursedetails />
          </Route>
          <Route path="/courselist">
            <Courselist />
          </Route>
          
        </Switch>
      </div>
    </Router>
  );
}



